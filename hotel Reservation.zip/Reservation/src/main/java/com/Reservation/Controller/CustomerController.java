package com.Reservation.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Reservation.Exception.PasswordMismatchException;
import com.Reservation.Repository.CustomerRepository;
import com.Reservation.Request.Login;
import com.Reservation.Request.CustomerModel;
import com.Reservation.Resources.AppConstant;
import com.Reservation.Response.BaseApiResponse;
import com.Reservation.Response.ResponseBuilder;
import com.Reservation.Service.CustomerService;

@RestController
@RequestMapping("/user")
public class CustomerController {
	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerService customerService;

	@PostMapping("/register")
	public ResponseEntity<?> createUser(@RequestBody CustomerModel customerModel) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(customerService.createCustomer(customerModel));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody Login authenticationRequest) throws Exception {

		CustomerModel customer=customerService.findByEmail(authenticationRequest.getEmail());

		authenticate(customer,authenticationRequest.getEmail(), authenticationRequest.getPassword());

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(
				customerService.verifyLogin(authenticationRequest.getEmail(), authenticationRequest.getPassword()));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

	private void authenticate(CustomerModel user, String username, String password) throws Exception {
		
		if (!password.equals(user.getPassword())) {
			throw new PasswordMismatchException(AppConstant.ErrorTypes.PASSWORD_MISMATCH_ERROR,
					AppConstant.ErrorCodes.PASSWORD_MISMATCH_ERROR_CODE,
					AppConstant.ErrorMessages.PASSWORD_MISMATCH_MESSAGE);
		}
	}
	
//	@GetMapping("getData"+ "/{id}")
//	public ResponseEntity<?> getUserById(@PathVariable("id") Integer id) {
//		BaseApiResponse baseApiResponse = null;
//
//		baseApiResponse = ResponseBuilder.getSuccessResponse(customerService.findCustomerEntityByIds(id));
//		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
//	}
	
	
}
