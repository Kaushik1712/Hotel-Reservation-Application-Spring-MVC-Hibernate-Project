package com.Reservation.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Reservation.entities.RoomEntity;
import com.Reservation.Request.RoomModel;
import com.Reservation.Response.BaseApiResponse;
import com.Reservation.Response.ResponseBuilder;
import com.Reservation.Service.RoomService;

@RestController
@RequestMapping("/room")
public class BookController {
	@Autowired
	RoomService roomService;
	int counter=0;
	@PostMapping("/booking")
	public ResponseEntity<?> createRoom(@RequestBody RoomModel roomModel) {

		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(roomService.createRoom(roomModel));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}

	@PutMapping("/updateRoomBooking")
	public ResponseEntity<?> roomUpdate(@RequestBody RoomModel roomModel) {

		BaseApiResponse baseApiResponse = ResponseBuilder
				.getSuccessResponse(roomService.roomUpdate(roomModel));

		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteRoom" + "/{id}")
	public ResponseEntity<?> deleteUserById(@PathVariable Integer id) {
		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(roomService.deleteRoom(id));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);

	}
	
	
	@GetMapping("/getStatus"+"/{status}")
	public ResponseEntity<?> getUserById(@PathVariable Integer status) {
		BaseApiResponse baseApiResponse = null;
		baseApiResponse = ResponseBuilder.getSuccessResponse(roomService.findStatusEntityByIds(status));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	
//	@GetMapping("/getRoom" + "/{id}")
//	public ResponseEntity<?> findById(@PathVariable Integer id) {
//		BaseApiResponse baseApiResponse = ResponseBuilder.getSuccessResponse(roomService.findByIds1(id));
//		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
//
//	}
	
	@GetMapping("getRoom"+ "/{id}")
	public ResponseEntity<?> getRoomById(@PathVariable("id") Integer id) {
		BaseApiResponse baseApiResponse = null;

		baseApiResponse = ResponseBuilder.getSuccessResponse(roomService.findByRoomId(id));
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	

}
