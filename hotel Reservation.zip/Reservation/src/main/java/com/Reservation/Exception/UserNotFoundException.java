package com.Reservation.Exception;

public class UserNotFoundException extends AppException {
private static final long serialVersionUID = 1L;
	
	public UserNotFoundException(String errorType, String errorCode, String message) {
		super(errorType, errorCode, message);
	}
}
