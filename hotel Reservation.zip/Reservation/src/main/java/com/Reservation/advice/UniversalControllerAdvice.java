package com.Reservation.advice;

import java.net.http.HttpHeaders;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.Reservation.Exception.EmailExistException;
import com.Reservation.Exception.InvalidInputException;
import com.Reservation.Exception.PasswordMismatchException;
import com.Reservation.Exception.UserNotFoundException;
import com.Reservation.Resources.AppConstant;
import com.Reservation.Response.BaseApiResponse;
import com.Reservation.Response.ResponseStatus;

public class UniversalControllerAdvice extends ResponseEntityExceptionHandler {

	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<FieldError> allBindingErrorsList = ex.getBindingResult().getFieldErrors();
		List<String> allBindingErrorsMessageList = new ArrayList<String>();

		for (FieldError error : allBindingErrorsList) {
			allBindingErrorsMessageList.add(error.getField() + " - " + error.getDefaultMessage());
		}

		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));

		InvalidInputException invalidInputException = new InvalidInputException(
				AppConstant.ErrorTypes.INVALID_INPUT_ERROR, AppConstant.ErrorCodes.INVALID_INPUT_ERROR_CODE,
				allBindingErrorsMessageList.toString());

		baseApiResponse.setResponseData(invalidInputException);

		return new ResponseEntity<Object>(baseApiResponse, HttpStatus.OK);

	}
	@ExceptionHandler(EmailExistException.class)
	public ResponseEntity<BaseApiResponse> emailExistException(EmailExistException emailExistException,
			HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(emailExistException);
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	
	@ExceptionHandler(PasswordMismatchException.class)
	public ResponseEntity<BaseApiResponse> passwordMismatchException(
			PasswordMismatchException passwordMismatchException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(passwordMismatchException);
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<BaseApiResponse> userNotFoundException(
			UserNotFoundException userNotFoundException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstant.StatusCodes.FAILURE));
		baseApiResponse.setResponseData(userNotFoundException);
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
}
