package com.Reservation.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Reservation.Exception.EmailExistException;
import com.Reservation.Exception.PasswordMismatchException;
import com.Reservation.Exception.UserNotFoundException;
import com.Reservation.Repository.CustomerRepository;
import com.Reservation.Request.CustomerModel;
import com.Reservation.Request.LoginResponse;
import com.Reservation.Resources.AppConstant;
import com.Reservation.entities.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	public CustomerModel createCustomer(CustomerModel customerModel) {
		if (customerRepository.existsByEmail(customerModel.getEmail())) {

			throw new EmailExistException(AppConstant.ErrorTypes.EMAIL_EXIST_ERROR,
					AppConstant.ErrorCodes.EMAIL_EXIST_ERROR_CODE, AppConstant.ErrorMessages.EMAIL_EXIST_MESSAGE);

		} else {
			return convertToModel(customerRepository.save(convertToEntity(customerModel)));
		}

	}
	
	public LoginResponse verifyLogin(String email, String password) {


		CustomerModel user = findByEmail(email);

		String rawPassword = password;

		if (rawPassword.equals(user.getPassword())) {

			return convertToModel(user);
		} else {
			throw new PasswordMismatchException(AppConstant.ErrorTypes.PASSWORD_MISMATCH_ERROR,
					AppConstant.ErrorCodes.PASSWORD_MISMATCH_ERROR_CODE,
					AppConstant.ErrorMessages.PASSWORD_MISMATCH_MESSAGE);

		}

	}

	public Customer findByIds(Integer id) {

		if (id != null) {

			return customerRepository.findById(id)
					.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
							AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE));

		} else {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGES);

		}
	}

	public CustomerModel findById(Integer id) {

		if (id == null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_EMPTY_EXIST_MESSAGE);
		} else {
			return convertToModel(customerRepository.findById(id)
					.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
							AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE)));
		}

	}
	
	public CustomerModel findByEmail(String email) {
		Customer customer = customerRepository.getUserByEmail(email);
		if (customer != null) {
			return convertToModel(customer);
		} else {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE);
		}
	}
	public LoginResponse convertToModel(CustomerModel customerModel) {

		return LoginResponse.builder().id(customerModel.getId()).name(customerModel.getName())
				.email(customerModel.getEmail()).build();

	}

	public Customer convertToEntity(CustomerModel model) {

		return Customer.builder().id(model.getId()).name(model.getName()).email(model.getEmail())
				.password(model.getPassword()).build();
	}

	public CustomerModel convertToModel(Customer entity) {

		return CustomerModel.builder().id(entity.getId()).name(entity.getName()).email(entity.getEmail())
				.password(entity.getPassword()).build();

	}

}
