package com.Reservation.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Reservation.Exception.UserNotFoundException;
import com.Reservation.Repository.RoomRepository;
import com.Reservation.Request.RoomModel;
import com.Reservation.Resources.AppConstant;
import com.Reservation.entities.RoomEntity;

@Service
public class RoomService {

	@Autowired
	RoomRepository roomRepository;

	@Autowired
	RoomService roomService;

	@Autowired
	CustomerService customerService;

	public RoomModel createRoom(RoomModel roomModel) {
		// System.out.println(customerService.findByIds(roomModel.getCustomerModel().getId()));

		return convertToModel(roomRepository.save(convertToEntity(roomModel)));
	}

	public RoomEntity convertToEntity(RoomModel model) {
		// System.out.println(customerService.findByIds(model.getCustomerModel().getId()));
		return RoomEntity.builder().RoomId(model.getRoomId()).roomname(model.getRoomname())
				.customer(customerService.findByIds(model.getCustomerModel().getId())).build();
	}

	public RoomModel convertToModel(RoomEntity entity) {

		return RoomModel.builder().roomId(entity.getRoomId()).roomname(entity.getRoomname())
				.customerModel(customerService.findById(entity.getCustomer().getId())).build();
	}

	public RoomEntity findByIds(Integer id) {

		if (id != null) {

			return roomRepository.findById(id)
					.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
							AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE));

		} else {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGES);

		}
	}

	public RoomModel findById(Integer id) {

		if (id == null) {
			throw new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
					AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
					AppConstant.ErrorMessages.USER_EMPTY_EXIST_MESSAGE);
		} else {
			return convertToModel(roomRepository.findById(id)
					.orElseThrow(() -> new UserNotFoundException(AppConstant.ErrorTypes.USER_NOT_EXIST_ERROR,
							AppConstant.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE,
							AppConstant.ErrorMessages.USER_NOT_EXIST_MESSAGE)));
		}

	}

	public RoomModel roomUpdate(RoomModel roomModel) {

		RoomModel room = findById(roomModel.getRoomId());

		room.setRoomId(room.getRoomId());
		return convertToModel(roomRepository.save(convertToEntity(roomModel)));
	}

	public RoomModel deleteRoom(Integer id) {

		RoomEntity room = roomRepository.findById(id).get();
		room.setStatus(1);
		return convertToModel(roomRepository.save(room));

	}

//	get by status
	public List<RoomEntity> findStatusEntityByIds(Integer status) {

		List<RoomEntity> room = new ArrayList<>();
		if (status == 0) {

			roomRepository.findByStatus(status).forEach(room::add);
		}
		return room;
	}

//	public Optional<Room> findByIds1(Integer id) {
//		Optional<Room> room = roomRepository.findById(id);
//		if(room.equals(id)) {
//			return room;
//		}
//		else {
//			return null;
//		}
//	
//	}

	public RoomEntity findByRoomId(Integer id) {
		return findByIds(id);
	}

}
