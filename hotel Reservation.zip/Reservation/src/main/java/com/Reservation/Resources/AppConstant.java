package com.Reservation.Resources;

public interface AppConstant {
	public interface StatusCodes {
		int SUCCESS = 0;
		int FAILURE = 1;
	}
	
	public interface ErrorTypes{
		String INVALID_INPUT_ERROR = "Invalid Input";
		String EMAIL_EXIST_ERROR = "Email Exist";
		String USER_NOT_EXIST_ERROR = "Does not Exist";
		String PASSWORD_MISMATCH_ERROR = "Mismatch";
		String MASTER_STATE_EXIST_ERROR = "Does Not Exist";
		
	}
	
	public interface ErrorCodes{
		String INVALID_INPUT_ERROR_CODE = "102";
		String EMAIL_EXIST_ERROR_CODE = "103";
		String USER_DOES_NOT_EXISTS_ERROR_CODE = "104";
		String PASSWORD_MISMATCH_ERROR_CODE = "105";
		String MASTER_STATE_ERROR_CODE = "106";
		
	}
	
	public interface ErrorMessages {
		
		String INVALID_INPUT_MESSAGE = "Invalid Input";
		String EMAIL_EXIST_MESSAGE = "Email Already Exist";
		String USER_NOT_EXIST_MESSAGE = "Email Does not Exist";
		String PASSWORD_MISMATCH_MESSAGE = "Password Mismatch";
		String USER_EMPTY_EXIST_MESSAGE = "User Does Not Exists";
		String ID_EMPTY_MESSAGE = "Id Should Not be Null";
		
		String USER_NOT_EXIST_MESSAGES = "Error Does not exist";
		
	}

}
