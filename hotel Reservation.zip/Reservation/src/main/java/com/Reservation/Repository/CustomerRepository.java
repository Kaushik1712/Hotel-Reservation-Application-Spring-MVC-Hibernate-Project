package com.Reservation.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Reservation.entities.Customer;


@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
Boolean existsByEmail(String email);
	
	public Customer getUserByEmail(String email);

}
