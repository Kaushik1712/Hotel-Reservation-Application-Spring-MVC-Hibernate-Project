package com.Reservation.Request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoomModel {

	private Integer roomId;

	private String roomname;

	private CustomerModel customerModel;

	private int status;
}
